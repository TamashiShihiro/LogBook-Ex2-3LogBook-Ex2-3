package com.example.logbookex2;

import android.os.Bundle;
import android.app.AlertDialog;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {

    Button btnAdd, btnEdit, btnDelete;
    ListView listViewTasks;
    ArrayList<String> taskList;
    ArrayAdapter<String> adapter;

    int selectedPosition = -1;
    TaskDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdd = findViewById(R.id.btnAdd);
        btnEdit = findViewById(R.id.btnEdit);
        btnDelete = findViewById(R.id.btnDelete);
        listViewTasks = findViewById(R.id.listViewTasks);

        dbHelper = new TaskDbHelper(this);

        taskList = new ArrayList<String>();
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, taskList);
        listViewTasks.setAdapter(adapter);

        listViewTasks.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        loadTasksFromDb();

        listViewTasks.setOnItemClickListener((parent, view, position, id) -> {
            selectedPosition = position;
            listViewTasks.setItemChecked(position, true);
        });


        btnAdd.setOnClickListener(v -> showAddDialog());

        btnEdit.setOnClickListener(v -> {
                    if (selectedPosition != -1) {
                        showEditDialog(taskList.get(selectedPosition));
                    } else {
                        Toast.makeText(this, "Select a task to edit", Toast.LENGTH_SHORT).show();
                    }
                });

        btnDelete.setOnClickListener(v -> {
            if (selectedPosition != -1) {
                String taskToDelete = taskList.get(selectedPosition);
                dbHelper.deleteTask(taskToDelete);
                taskList.remove(selectedPosition);
                adapter.notifyDataSetChanged();
                selectedPosition = -1;
                Toast.makeText(this, "Task deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Select a task to delete", Toast.LENGTH_SHORT).show();
            }

        });
    }

    private void showAddDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Task");

        final EditText input = new EditText(this);
        input.setHint("Enter task");
        builder.setView(input);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String taskName = input.getText().toString();
            if (!taskName.isEmpty()) {
                dbHelper.addTask(taskName);
                taskList.add(taskName);
                adapter.notifyDataSetChanged();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();

    }

    private void showEditDialog(String taskName) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Task");

        final EditText input = new EditText(this);
        input.setText(taskName);
        builder.setView(input);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String newTaskName = input.getText().toString();
            if (!newTaskName.isEmpty()) {
                dbHelper.updateTask(taskName, newTaskName);
                taskList.set(selectedPosition, newTaskName);
                adapter.notifyDataSetChanged();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();

    }

    private void loadTasksFromDb() {
        taskList.clear();
        Cursor cursor = dbHelper.getAllTasks();
        if (cursor.moveToFirst()) {
            do {
                taskList.add(cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter.notifyDataSetChanged();
    }
    static class TaskDbHelper extends SQLiteOpenHelper {
        private static final String Db_NAME = "tasks.db";
        private static final int Db_VERSION = 1;

        public TaskDbHelper(MainActivity context) {
            super(context, Db_NAME, null, Db_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE tasks (name TEXT PRIMARY KEY)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS tasks");
            onCreate(db);
        }

        public void addTask(String taskName) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("name", taskName);
            db.insert("tasks", null, values);
        }

        public void updateTask(String oldName, String newName) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("name", newName);
            db.update("tasks", values, "name=?", new String[]{oldName});
        }

        public void deleteTask(String taskName) {
            SQLiteDatabase db = this.getWritableDatabase();
            db.delete("tasks", "name=?", new String[]{taskName});
        }

        public Cursor getAllTasks() {
            SQLiteDatabase db = this.getReadableDatabase();
            return db.rawQuery("SELECT name FROM tasks", null);
        }

    }
};