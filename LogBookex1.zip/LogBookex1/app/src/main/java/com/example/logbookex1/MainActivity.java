package com.example.logbookex1;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {

    private EditText inputValue;
    private Spinner unitSpinner;
    private Button convertBtn;
    private TextView resultMetre, resultMillimetre, resultMile, resultFoot;

    private final HashMap<String, Double> toMetre = new HashMap<String, Double>() {{

        put("Metre", 1.0);
        put("Millimetre", 0.001);
        put("Mile", 1609.34);
        put("Foot", 0.3048);
    }};

    private String selectedUnit = "Metre";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputValue = findViewById(R.id.edit_input);

        unitSpinner = findViewById(R.id.spinner_units);

        convertBtn = findViewById(R.id.btn_convert);

        resultMetre = findViewById(R.id.result_metre);
        resultMile = findViewById(R.id.result_mile);
        resultMillimetre = findViewById(R.id.result_millimetre);
        resultFoot = findViewById(R.id.result_foot);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                toMetre.keySet().toArray(new String[0]));

        adapter.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item
                );

        unitSpinner.setAdapter(adapter);

        unitSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedUnit = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        convertBtn.setOnClickListener(v -> convert());

    }

    private void convert() {
        String inputString = inputValue.getText().toString();
        if (inputString.isEmpty()) return;

        double input = Double.parseDouble(inputString);
        double inMetre = input * toMetre.get(selectedUnit);

        DecimalFormat df = new DecimalFormat("#.####");

        resultMetre.setText("Metre: " + df.format(inMetre / toMetre.get("Metre")));
        resultMillimetre.setText("Millimetre: " + df.format(inMetre / toMetre.get("Millimetre")));
        resultMile.setText("Mile: " + df.format(inMetre / toMetre.get("Mile")));
        resultFoot.setText("Foot: " + df.format(inMetre / toMetre.get("Foot")));
    }

}